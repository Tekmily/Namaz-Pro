import { Coordinates, CalculationMethod, PrayerTimes } from 'adhan';

const coordinates = new Coordinates(50.1109, 8.6821);
const date = new Date(2026, 2, 12); // March 12, 2026
const params = CalculationMethod.Turkey(); // Diyanet method

const prayerTimes = new PrayerTimes(coordinates, date, params);

console.log('Fajr:', prayerTimes.fajr);
console.log('Sunrise:', prayerTimes.sunrise);
console.log('Dhuhr:', prayerTimes.dhuhr);
console.log('Asr:', prayerTimes.asr);
console.log('Maghrib:', prayerTimes.maghrib);
console.log('Isha:', prayerTimes.isha);
