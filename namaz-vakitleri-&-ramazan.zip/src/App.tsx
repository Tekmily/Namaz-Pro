import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Search, RefreshCw, Navigation, Moon, Sun, Clock, Calendar, Bell, BellOff, PlayCircle, Volume2, VolumeX, Settings } from 'lucide-react';
import { translations, getMoonPhase } from './constants';
import { FlipClock } from './components/FlipClock';
import { PrayerModal } from './components/PrayerModal';
import { MonthlyCalendarModal } from './components/MonthlyCalendarModal';
import { TemkinModal, TemkinOffsets } from './components/TemkinModal';

export default function App() {
  const [lang, setLang] = useState<'tr'>('tr');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [location, setLocation] = useState<{ lat: number, lon: number, name: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [prayerData, setPrayerData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [notifPerm, setNotifPerm] = useState<NotificationPermission>('default');
  const [notifiedPrayers, setNotifiedPrayers] = useState<Set<string>>(new Set());
  const [imageIndex, setImageIndex] = useState(0);
  const [selectedPrayer, setSelectedPrayer] = useState<string | null>(null);
  const [activeVideoIndex, setActiveVideoIndex] = useState(0);
  const [isAdhanEnabled, setIsAdhanEnabled] = useState(false);
  const [playingAdhan, setPlayingAdhan] = useState<string | null>(null);
  const [lastPlayedPrayer, setLastPlayedPrayer] = useState<string | null>(null);
  const [showMonthlyCalendar, setShowMonthlyCalendar] = useState(false);
  const [showTemkinModal, setShowTemkinModal] = useState(false);
  const [temkin, setTemkin] = useState<TemkinOffsets>({
    Imsak: 0, Sunrise: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0
  });

  const t = translations[lang];
  const moonPhase = getMoonPhase(currentTime);

  const ramadanVideos = [
    { id: '25cjM4047vc', list: 'RD25cjM4047vc', title: 'Ramazan İlahileri & Müzikleri 1' },
    { id: 'tBbdSzwxqyY', list: 'RDEMR8te1sAiXuQZdmoa4rThJw', title: 'Ramazan İlahileri & Müzikleri 2' },
    { id: 'iBd1r5VOK2c', list: 'RDEM6rJK4ToIcQ6dYHUerXhqZg', title: 'Ramazan İlahileri & Müzikleri 3' },
    { id: 'e2FKXPzsT7E', list: 'RDEM1Y7NQHpWWflJxGnhe4cAtQ', title: 'Ramazan İlahileri & Müzikleri 4' },
    { id: 'u_-McEvEGvI', list: 'RDEM6rybi08Zh-3tdKVotIDgdQ', title: 'Ramazan İlahileri & Müzikleri 5' },
    { id: '-7LUNVWVHeE', list: 'RD-7LUNVWVHeE', title: 'Ramazan İlahileri & Müzikleri 6' },
    { id: 'XFPeblMoqTw', list: 'RDXFPeblMoqTw', title: 'Ramazan İlahileri & Müzikleri 7' },
  ];

  useEffect(() => {
    const saved = localStorage.getItem('lastLocation');
    const savedTemkin = localStorage.getItem('temkin');
    let initialTemkin = { Imsak: 0, Sunrise: 0, Dhuhr: 0, Asr: 0, Maghrib: 0, Isha: 0 };
    
    if (savedTemkin) {
      try {
        initialTemkin = JSON.parse(savedTemkin);
        setTemkin(initialTemkin);
      } catch (e) {}
    }

    if (saved) {
      const { lat, lon, name } = JSON.parse(saved);
      fetchPrayerTimes(lat, lon, name, initialTemkin);
    }
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
      setTheme(savedTheme);
    }
    if ('Notification' in window) setNotifPerm(Notification.permission);
  }, []);

  useEffect(() => {
    const imgTimer = setInterval(() => setImageIndex((prev) => (prev + 1) % 2), 10000);
    return () => clearInterval(imgTimer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);

      if (prayerData && notifPerm === 'granted') {
        const timezone = prayerData.meta.timezone;
        const tzNowStr = now.toLocaleString("en-US", { timeZone: timezone });
        const tzNow = new Date(tzNowStr);
        
        const currentHour = tzNow.getHours();
        const currentMinute = tzNow.getMinutes();
        const currentSecond = tzNow.getSeconds();

        const prayerKeys = ["Imsak", "Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];
        
        prayerKeys.forEach(key => {
          const [pHour, pMinute] = prayerData.timings[key].split(':').map(Number);
          const notifKey = `${prayerData.date.gregorian.date}-${key}`;
          
          if (currentHour === pHour && currentMinute === pMinute && currentSecond === 0) {
            if (!notifiedPrayers.has(notifKey)) {
              new Notification(t.notifTitle, {
                body: `${t.prayers[key as keyof typeof t.prayers]} ${t.notifBody}`,
                icon: 'https://cdn-icons-png.flaticon.com/512/3073/3073986.png'
              });
              setNotifiedPrayers(prev => new Set(prev).add(notifKey));
            }
          }
        });
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [prayerData, notifPerm, notifiedPrayers, t]);

  useEffect(() => {
    if (!prayerData || !isAdhanEnabled) return;

    const timezone = prayerData.meta.timezone;
    const tzNowStr = currentTime.toLocaleString("en-US", { timeZone: timezone });
    const tzNow = new Date(tzNowStr);

    const currentHour = tzNow.getHours();
    const currentMinute = tzNow.getMinutes();

    const prayerKeys = ["Imsak", "Fajr", "Dhuhr", "Asr", "Maghrib", "Isha"];
    
    for (const key of prayerKeys) {
      const [pHour, pMinute] = prayerData.timings[key].split(':').map(Number);
      if (pHour === currentHour && pMinute === currentMinute) {
        const prayerId = `${prayerData.date.gregorian.date}-${key}`;
        if (lastPlayedPrayer !== prayerId) {
          playAdhan(key);
          setLastPlayedPrayer(prayerId);
        }
        break;
      }
    }
  }, [currentTime, prayerData, isAdhanEnabled, lastPlayedPrayer]);

  const playAdhan = (prayerKey: string) => {
    let videoId = '';
    const isRamadan = prayerData?.date?.hijri?.month?.number === 9;

    switch (prayerKey) {
      case 'Imsak':
      case 'Fajr':
        videoId = 'JMjQ9n2NuzU';
        break;
      case 'Dhuhr':
        videoId = 'TfewIb0JxEA';
        break;
      case 'Asr':
        videoId = 'X1uqKicTuXY';
        break;
      case 'Maghrib':
        videoId = isRamadan ? '3zkrwt8PEgQ' : 'XoJEDT0J3Uc';
        break;
      case 'Isha':
        videoId = 'zeYwVacb7K4';
        break;
    }

    if (videoId) {
      setPlayingAdhan(videoId);
      // Auto clear iframe after 6 minutes (360000ms) to ensure it stops playing
      setTimeout(() => setPlayingAdhan(null), 360000);
    }
  };

  const addMinutesToTime = (timeStr: string, minutes: number) => {
    if (!minutes) return timeStr;
    const [h, m] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(h, m + minutes, 0, 0);
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  };

  const fetchPrayerTimes = async (lat: number, lon: number, name: string, currentTemkin: TemkinOffsets = temkin) => {
    setLoading(true); setError('');
    try {
      const parts = name.split(',');
      const city = parts[0].trim();
      const country = parts.length > 1 ? parts[parts.length - 1].trim() : 'Turkey';

      // 1. Fetch base data from Aladhan (for timezone, hijri date, and fallback)
      const aladhanRes = await fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=13`);
      const aladhanData = await aladhanRes.json();
      
      if (aladhanData.code === 200) {
        let finalData = aladhanData.data;

        // 2. Try to fetch exact Diyanet data
        try {
          const searchRes = await fetch(`https://ezanvakti.imsakiyem.com/api/locations/search/districts?q=${encodeURIComponent(city)}`);
          const searchData = await searchRes.json();
          
          if (searchData.success && searchData.data && searchData.data.length > 0) {
            const districtId = searchData.data[0]._id;
            const diyanetRes = await fetch(`https://ezanvakti.imsakiyem.com/api/prayer-times/${districtId}/daily`);
            const diyanetData = await diyanetRes.json();
            
            if (diyanetData.success && diyanetData.data && diyanetData.data.length > 0) {
              const dTimes = diyanetData.data[0].times;
              // Overwrite timings with exact Diyanet times
              finalData.timings = {
                ...finalData.timings,
                Imsak: dTimes.imsak,
                Fajr: dTimes.imsak,
                Sunrise: dTimes.gunes,
                Dhuhr: dTimes.ogle,
                Asr: dTimes.ikindi,
                Maghrib: dTimes.aksam,
                Isha: dTimes.yatsi
              };
              finalData.meta.source = "Diyanet İşleri Başkanlığı (Resmi)";
            }
          }
        } catch (e) {
          console.error("Diyanet API error, falling back to Aladhan:", e);
        }

        // 3. Apply Temkin offsets
        finalData.timings.Imsak = addMinutesToTime(finalData.timings.Imsak, currentTemkin.Imsak);
        finalData.timings.Fajr = addMinutesToTime(finalData.timings.Fajr, currentTemkin.Imsak);
        finalData.timings.Sunrise = addMinutesToTime(finalData.timings.Sunrise, currentTemkin.Sunrise);
        finalData.timings.Dhuhr = addMinutesToTime(finalData.timings.Dhuhr, currentTemkin.Dhuhr);
        finalData.timings.Asr = addMinutesToTime(finalData.timings.Asr, currentTemkin.Asr);
        finalData.timings.Maghrib = addMinutesToTime(finalData.timings.Maghrib, currentTemkin.Maghrib);
        finalData.timings.Isha = addMinutesToTime(finalData.timings.Isha, currentTemkin.Isha);

        setPrayerData(finalData);
        setLocation({ lat, lon, name });
        localStorage.setItem('lastLocation', JSON.stringify({ lat, lon, name }));
      } else {
        setError(t.error);
      }
    } catch (err) { 
      setError(t.error); 
    } finally { 
      setLoading(false); 
    }
  };

  const handleSearch = async () => {
    if (!searchQuery) return;
    setLoading(true); setError('');
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchQuery)}&format=json&limit=1&accept-language=${lang}`);
      const data = await res.json();
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        const name = data[0].display_name.split(',')[0] + ', ' + data[0].display_name.split(',').pop();
        fetchPrayerTimes(lat, lon, name);
      } else { setError(t.locationError); setLoading(false); }
    } catch (err) { setError(t.error); setLoading(false); }
  };

  const handleAutoLocation = () => {
    if (!navigator.geolocation) { setError(t.locationError); return; }
    setLoading(true); setError('');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const lat = pos.coords.latitude; const lon = pos.coords.longitude;
        try {
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&accept-language=${lang}`);
          const data = await res.json();
          const name = data.address?.city || data.address?.town || data.address?.village || data.display_name.split(',')[0];
          fetchPrayerTimes(lat, lon, name);
        } catch { fetchPrayerTimes(lat, lon, `${lat.toFixed(4)}, ${lon.toFixed(4)}`); }
      },
      (err) => { setError(t.locationError); setLoading(false); },
      { timeout: 10000, maximumAge: 60000, enableHighAccuracy: true }
    );
  };

  const requestNotification = async () => {
    if ('Notification' in window) {
      const perm = await Notification.requestPermission();
      setNotifPerm(perm);
    } else alert("Tarayıcınız bildirimleri desteklemiyor.");
  };

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
  };

  // --- Time Calculations ---
  let nextPrayer: any = null;
  let currentPrayer: any = null;
  let diffHrs = 0, diffMins = 0, diffSecs = 0;
  let progressPercent = 0;
  
  if (prayerData) {
    const timezone = prayerData.meta.timezone;
    const tzNowStr = currentTime.toLocaleString("en-US", { timeZone: timezone });
    const tzNow = new Date(tzNowStr);
    
    const prayerKeys = ["Imsak", "Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];
    
    const times = prayerKeys.map(key => {
      const [hours, minutes] = prayerData.timings[key].split(':').map(Number);
      const prayerTime = new Date(tzNow);
      prayerTime.setHours(hours, minutes, 0, 0);
      return { key, time: prayerData.timings[key], date: prayerTime };
    });

    let foundNext = false;
    for (let i = 0; i < times.length; i++) {
      if (times[i].date.getTime() > tzNow.getTime()) {
        nextPrayer = times[i];
        currentPrayer = i > 0 ? times[i - 1] : times[times.length - 1];
        foundNext = true;
        break;
      }
    }
    if (!foundNext) {
      const tomorrowImsak = new Date(times[0].date);
      tomorrowImsak.setDate(tomorrowImsak.getDate() + 1);
      nextPrayer = { ...times[0], date: tomorrowImsak };
      currentPrayer = times[times.length - 1];
    }
    
    if (nextPrayer && currentPrayer) {
      const diffMs = nextPrayer.date.getTime() - tzNow.getTime();
      diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
      diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      diffSecs = Math.floor((diffMs % (1000 * 60)) / 1000);

      const totalMs = nextPrayer.date.getTime() - currentPrayer.date.getTime();
      const elapsedMs = tzNow.getTime() - currentPrayer.date.getTime();
      progressPercent = Math.max(0, Math.min(100, (elapsedMs / totalMs) * 100));
    }
  }

  const periodGradients: Record<string, string> = {
    Imsak: "from-indigo-950 via-indigo-800 to-sky-700",
    Fajr: "from-sky-700 via-sky-500 to-amber-200",
    Sunrise: "from-amber-200 via-orange-300 to-sky-400",
    Dhuhr: "from-sky-400 via-blue-400 to-sky-500",
    Asr: "from-sky-500 via-orange-400 to-rose-500",
    Maghrib: "from-rose-500 via-purple-700 to-indigo-900",
    Isha: "from-indigo-900 via-slate-800 to-black"
  };

  const periodIcons: Record<string, string> = {
    Imsak: "🌌", Fajr: "🌅", Sunrise: "☀️", Dhuhr: "☀️", Asr: "🌤️", Maghrib: "🌇", Isha: "🌙"
  };

  const isRamadan = prayerData?.date?.hijri?.month?.number === 9;

  return (
    <div className={`min-h-screen font-sans transition-colors duration-500 relative overflow-hidden ${theme === 'light' ? 'light-theme bg-slate-50 text-slate-800' : 'bg-[#020617] text-slate-100'}`}>
      
      {/* Animated Background Gradients */}
      <motion.div animate={{ scale: [1, 1.1, 1], opacity: [0.2, 0.3, 0.2] }} transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }} className={`absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full blur-[120px] pointer-events-none ${theme === 'dark' ? 'bg-sky-900/30' : 'bg-sky-300/40'}`} />
      <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }} transition={{ duration: 10, repeat: Infinity, ease: "easeInOut", delay: 1 }} className={`absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] rounded-full blur-[120px] pointer-events-none ${theme === 'dark' ? 'bg-indigo-900/30' : 'bg-indigo-300/40'}`} />

      <div className="max-w-6xl mx-auto p-4 md:p-8 space-y-6 relative z-10">
        
        {/* Header */}
        <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl border backdrop-blur-xl shadow-2xl transition-colors duration-500 ${theme === 'dark' ? 'bg-slate-900/50 border-slate-800/60' : 'bg-white/60 border-slate-200/60'}`}>
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center shadow-lg shadow-sky-500/30">
              <Moon className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className={`text-2xl font-bold tracking-tight drop-shadow-sm ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>{t.title}</h1>
              <p className={`text-sm mt-0.5 ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>{t.subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full shadow-inner border ${theme === 'dark' ? 'bg-slate-800/60 border-slate-700/50' : 'bg-slate-100 border-slate-200'}`}>
              <span className="text-xl">{moonPhase.emoji}</span>
              <span className={`text-sm font-medium ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                {location ? `${location.name.split(',')[0]} • ` : ''}{t.moonPhases[moonPhase.key as keyof typeof t.moonPhases]}
              </span>
            </div>
            <button onClick={() => setShowTemkinModal(true)} title="Temkin Ayarları" className={`p-2.5 rounded-full transition-colors shadow-inner border ${theme === 'dark' ? 'bg-slate-800/80 border-slate-700/50 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}`}>
              <Settings className="w-5 h-5" />
            </button>
            <button onClick={() => setIsAdhanEnabled(!isAdhanEnabled)} title="Otomatik Ezan Sesi" className={`p-2.5 rounded-full transition-colors shadow-inner border ${theme === 'dark' ? 'bg-slate-800/80 border-slate-700/50 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}`}>
              {isAdhanEnabled ? <Volume2 className="w-5 h-5 text-emerald-500" /> : <VolumeX className="w-5 h-5" />}
            </button>
            <button onClick={requestNotification} className={`p-2.5 rounded-full transition-colors shadow-inner border ${theme === 'dark' ? 'bg-slate-800/80 border-slate-700/50 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}`}>
              {notifPerm === 'granted' ? <Bell className="w-5 h-5 text-sky-500" /> : <BellOff className="w-5 h-5" />}
            </button>
            <button onClick={toggleTheme} className={`p-2.5 rounded-full transition-colors shadow-inner border ${theme === 'dark' ? 'bg-slate-800/80 border-slate-700/50 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-600 hover:bg-slate-200'}`}>
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </motion.header>

        {/* Search & Location */}
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.1 }} className={`p-6 rounded-3xl border backdrop-blur-xl shadow-2xl space-y-5 transition-colors duration-500 ${theme === 'dark' ? 'bg-slate-900/50 border-slate-800/60' : 'bg-white/60 border-slate-200/60'}`}>
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSearch()} placeholder={t.searchPlaceholder} className={`w-full rounded-2xl pl-12 pr-4 py-4 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-all shadow-inner border ${theme === 'dark' ? 'bg-slate-950/60 border-slate-700/50 text-white placeholder:text-slate-500' : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'}`} />
              <Search className="absolute left-4 top-4 w-5 h-5 text-slate-400" />
            </div>
            <div className="flex gap-3">
              <button onClick={handleSearch} disabled={loading} className="flex-1 md:flex-none bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-400 hover:to-blue-500 text-white px-8 py-4 rounded-2xl font-semibold transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-sky-500/25 active:scale-95">
                {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <><Search className="w-5 h-5" /> {t.searchBtn}</>}
              </button>
              <button onClick={handleAutoLocation} disabled={loading} className={`flex-1 md:flex-none px-6 py-4 rounded-2xl font-medium transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg border ${theme === 'dark' ? 'bg-slate-800 hover:bg-slate-700 border-slate-700/50 text-white' : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'}`} title={t.useLocation}>
                <Navigation className="w-5 h-5 text-sky-500" />
                <span className="md:hidden">{t.useLocation}</span>
              </button>
            </div>
          </div>
          {error && <div className="text-red-500 text-sm px-4">{error}</div>}
          {location && !error && (
            <div className={`flex items-center gap-2 text-sm px-4 py-3 rounded-xl border inline-flex shadow-inner ${theme === 'dark' ? 'bg-emerald-500/10 border-emerald-500/20 text-slate-300' : 'bg-emerald-50 border-emerald-200 text-slate-700'}`}>
              <MapPin className="w-4 h-4 text-emerald-500" />
              <span className="truncate max-w-[250px] sm:max-w-md font-medium">{location.name}</span>
            </div>
          )}
        </motion.div>

        {/* Main Content */}
        {prayerData && currentPrayer && nextPrayer && (
          <div className="grid lg:grid-cols-12 gap-6">
            
            {/* Left Column: Countdowns & Ramadan */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="lg:col-span-5 space-y-6">
              
              {/* Combined Prayer & Ramadan Countdown Card */}
              <div className={`p-8 rounded-3xl border flex flex-col items-center justify-center text-center relative overflow-hidden shadow-2xl transition-colors duration-500 backdrop-blur-xl ${theme === 'dark' ? 'bg-slate-900/40 border-slate-700/50' : 'bg-white/40 border-white/60'}`}>
                
                {/* Background Image (Replacing YouTube Video) */}
                <AnimatePresence mode="wait">
                  <motion.div key={currentPrayer.key + imageIndex} initial={{ opacity: 0, scale: 1.05 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1 }} className="absolute inset-0 z-0 pointer-events-none">
                    <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${t.prayerDetails[currentPrayer.key as keyof typeof t.prayerDetails].images[imageIndex]})` }} />
                  </motion.div>
                </AnimatePresence>
                
                {/* Glass Overlay */}
                <div className={`absolute inset-0 z-0 backdrop-blur-md ${theme === 'dark' ? 'bg-slate-900/70' : 'bg-white/70'}`}></div>

                {/* Content */}
                <div className="relative z-10 flex flex-col items-center w-full gap-6">
                  
                  {/* Dynamic Header (Ramadan or Normal) */}
                  {isRamadan && nextPrayer.key === 'Maghrib' ? (
                    <div className={`inline-flex items-center gap-3 px-8 py-4 rounded-full border text-xl font-bold uppercase tracking-widest shadow-lg ${theme === 'dark' ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300' : 'bg-white/80 border-emerald-300 text-emerald-700'}`}>
                      <span className="text-3xl">🌙</span>
                      {t.ramadan.iftar}
                      <span className="text-3xl">⭐</span>
                    </div>
                  ) : isRamadan && nextPrayer.key === 'Imsak' ? (
                    <div className={`inline-flex items-center gap-3 px-8 py-4 rounded-full border text-xl font-bold uppercase tracking-widest shadow-lg ${theme === 'dark' ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300' : 'bg-white/80 border-emerald-300 text-emerald-700'}`}>
                      <span className="text-3xl">🌙</span>
                      {t.ramadan.sahur}
                      <span className="text-3xl">⭐</span>
                    </div>
                  ) : (
                    <div className={`inline-flex items-center gap-3 px-6 py-3 rounded-full border text-lg font-semibold uppercase tracking-wider shadow-inner ${theme === 'dark' ? 'bg-sky-500/20 border-sky-500/40 text-sky-200' : 'bg-white/80 border-sky-200 text-sky-700'}`}>
                      <Clock className="w-5 h-5" />
                      {t.prayers[nextPrayer.key as keyof typeof t.prayers]} {t.timeLeft}
                    </div>
                  )}
                  
                  {/* Professional Flip Clock */}
                  <FlipClock hours={diffHrs} minutes={diffMins} seconds={diffSecs} />
                  
                  {/* Progress Bar Section */}
                  <div className="w-full mt-4 space-y-3">
                    <div className="flex justify-between text-sm font-medium px-1 drop-shadow-md">
                      <span className={`flex items-center gap-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        <span className="text-lg">{periodIcons[currentPrayer.key]}</span> 
                        {t.prayers[currentPrayer.key as keyof typeof t.prayers]} ({currentPrayer.time})
                      </span>
                      <span className={`flex items-center gap-1.5 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-700'}`}>
                        {t.prayers[nextPrayer.key as keyof typeof t.prayers]} ({nextPrayer.time})
                        <span className="text-lg">{periodIcons[nextPrayer.key]}</span>
                      </span>
                    </div>
                    
                    <div className={`relative w-full h-10 rounded-full border shadow-inner overflow-visible ${theme === 'dark' ? 'bg-slate-900/80 border-slate-700' : 'bg-slate-200/80 border-slate-300'}`}>
                      {/* Track Fill */}
                      <div 
                        className={`absolute top-0 left-0 h-full rounded-full transition-all duration-1000 ease-linear shadow-[inset_0_0_10px_rgba(0,0,0,0.2)] overflow-hidden`}
                        style={{ width: `${progressPercent}%` }}
                      >
                         {/* Image inside the fill */}
                         <div className="absolute top-0 left-0 h-10 bg-cover bg-center" style={{ width: '100vw', maxWidth: '800px', backgroundImage: `url(${t.prayerDetails[currentPrayer.key as keyof typeof t.prayerDetails].images[imageIndex]})` }}></div>
                         {/* Gradient Overlay for better visibility */}
                         <div className={`absolute inset-0 bg-gradient-to-r ${periodGradients[currentPrayer.key]} opacity-70 mix-blend-overlay`}></div>
                      </div>
                      
                      {/* Moving Indicator */}
                      <div 
                        className="absolute top-1/2 -translate-y-1/2 w-12 h-12 bg-white/20 backdrop-blur-xl border-2 border-white/60 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.4)] transition-all duration-1000 ease-linear z-10"
                        style={{ left: `calc(${progressPercent}% - 24px)` }}
                      >
                        <span className="text-2xl drop-shadow-lg">
                          {['Maghrib', 'Isha', 'Imsak'].includes(currentPrayer.key) ? '🌙' : '☀️'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Date Info */}
                  <div className={`flex flex-col sm:flex-row items-center gap-3 text-sm px-6 py-3 rounded-2xl border shadow-inner w-full justify-center mt-2 ${theme === 'dark' ? 'bg-slate-950/40 border-slate-700/50 text-slate-200' : 'bg-white/60 border-slate-200 text-slate-800'}`}>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-indigo-400" />
                      <span className="font-medium">{prayerData.date.readable}</span>
                    </div>
                    <div className={`hidden sm:block w-1.5 h-1.5 rounded-full ${theme === 'dark' ? 'bg-slate-500' : 'bg-slate-300'}`}></div>
                    <div className={`font-medium ${theme === 'dark' ? 'text-sky-300' : 'text-sky-700'}`}>
                      {prayerData.date.hijri.day} {prayerData.date.hijri.month.en}
                    </div>
                  </div>

                  {/* Monthly Calendar Button */}
                  <button 
                    onClick={() => setShowMonthlyCalendar(true)}
                    className={`w-full py-3 px-6 rounded-2xl font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg border ${theme === 'dark' ? 'bg-indigo-600 hover:bg-indigo-500 border-indigo-500/50 text-white' : 'bg-indigo-500 hover:bg-indigo-600 border-indigo-600 text-white'}`}
                  >
                    <Calendar className="w-5 h-5" />
                    Aylık Takvimi Görüntüle
                  </button>

                </div>
              </div>

              {/* Ramadan Music / Media */}
              {isRamadan && (
                <div className={`p-6 rounded-3xl border backdrop-blur-xl shadow-2xl transition-colors duration-500 ${theme === 'dark' ? 'bg-slate-900/50 border-slate-800/60' : 'bg-white/60 border-slate-200/60'}`}>
                  <h3 className={`text-lg font-semibold mb-4 flex items-center gap-2 ${theme === 'dark' ? 'text-slate-200' : 'text-slate-800'}`}>
                    <PlayCircle className="w-5 h-5 text-rose-500" />
                    {t.ramadan.music}
                  </h3>
                  
                  <div className="space-y-4">
                    {/* Main Video Player */}
                    <div className="aspect-video rounded-xl overflow-hidden border border-slate-700/50 shadow-inner bg-black">
                      <iframe 
                        width="100%" 
                        height="100%" 
                        src={`https://www.youtube.com/embed/${ramadanVideos[activeVideoIndex].id}?list=${ramadanVideos[activeVideoIndex].list}`} 
                        title="YouTube video player" 
                        frameBorder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowFullScreen
                      ></iframe>
                    </div>
                    
                    {/* Playlist Selector */}
                    <div className="flex flex-col gap-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                      {ramadanVideos.map((video, idx) => (
                        <button 
                          key={video.id}
                          onClick={() => setActiveVideoIndex(idx)}
                          className={`flex items-center gap-3 p-2 rounded-xl transition-all text-left border ${
                            activeVideoIndex === idx 
                              ? (theme === 'dark' ? 'bg-sky-500/20 border-sky-500/40 text-sky-200 shadow-inner' : 'bg-sky-50 border-sky-300 text-sky-800 shadow-inner')
                              : (theme === 'dark' ? 'bg-slate-800/30 border-slate-700/30 text-slate-400 hover:bg-slate-800/60' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100')
                          }`}
                        >
                          <div className="relative w-24 aspect-video rounded-lg overflow-hidden flex-shrink-0 bg-slate-800 shadow-md">
                            <img 
                              src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`} 
                              alt={video.title}
                              className={`w-full h-full object-cover transition-opacity ${activeVideoIndex === idx ? 'opacity-60' : 'opacity-90'}`}
                            />
                            {activeVideoIndex === idx && (
                              <div className="absolute inset-0 flex items-center justify-center">
                                <PlayCircle className="w-8 h-8 text-white drop-shadow-md" />
                              </div>
                            )}
                          </div>
                          <span className="font-medium text-sm line-clamp-2">{video.title}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

            </motion.div>

            {/* Right Column: Prayer Times List */}
            <motion.div initial="hidden" animate="show" className={`lg:col-span-7 p-6 rounded-3xl border backdrop-blur-xl shadow-2xl transition-colors duration-500 ${theme === 'dark' ? 'bg-slate-900/50 border-slate-800/60' : 'bg-white/60 border-slate-200/60'}`}>
              <div className="space-y-4">
                {["Imsak", "Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"].map((key) => {
                  const isNext = nextPrayer?.key === key;
                  const details = t.prayerDetails[key as keyof typeof t.prayerDetails];
                  
                  return (
                    <motion.div 
                      key={key}
                      onClick={() => setSelectedPrayer(key)}
                      className={`relative overflow-hidden flex flex-col p-5 rounded-2xl transition-all duration-300 cursor-pointer group ${
                        isNext 
                          ? (theme === 'dark' ? 'border-sky-400/50 shadow-[0_0_30px_rgba(56,189,248,0.2)] scale-[1.02]' : 'border-sky-400 shadow-xl scale-[1.02]')
                          : (theme === 'dark' ? 'bg-slate-950/50 border border-slate-800/50 hover:bg-slate-800/80 hover:border-sky-500/30' : 'bg-white border border-slate-200 hover:bg-slate-50 hover:border-sky-300')
                      }`}
                    >
                      {isNext && (
                        <AnimatePresence mode="wait">
                          <motion.div key={imageIndex} initial={{ opacity: 0, scale: 1.05 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 1 }} className="absolute inset-0 z-0">
                            <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${details.images[imageIndex]})` }} />
                            <div className={`absolute inset-0 ${theme === 'dark' ? 'bg-slate-900/80' : 'bg-sky-900/70'}`} />
                          </motion.div>
                        </AnimatePresence>
                      )}

                      {!isNext && (
                        <div className="absolute right-[5%] top-[-20%] text-7xl opacity-[0.04] pointer-events-none select-none z-0 group-hover:scale-110 transition-transform duration-500">
                          {details.emoji.split('')[0]}
                        </div>
                      )}

                      <div className="flex items-center justify-between relative z-10">
                        <div className="flex items-center gap-4">
                          <div className={`w-14 h-14 rounded-xl flex items-center justify-center shadow-inner text-2xl ${
                            isNext ? 'bg-white/20 backdrop-blur-md text-white border border-white/30' : (theme === 'dark' ? 'bg-slate-800/80' : 'bg-slate-100')
                          }`}>
                            {details.emoji}
                          </div>
                          <span className={`text-xl font-medium ${isNext ? 'text-white font-bold drop-shadow-md' : (theme === 'dark' ? 'text-slate-200' : 'text-slate-700')}`}>
                            {t.prayers[key as keyof typeof t.prayers]}
                          </span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className={`font-mono text-3xl tracking-tight ${isNext ? 'text-white font-bold drop-shadow-md' : (theme === 'dark' ? 'text-slate-300' : 'text-slate-600')}`}>
                            {prayerData.timings[key]}
                          </span>
                          {/* Click indicator */}
                          <div className={`hidden sm:flex items-center justify-center w-8 h-8 rounded-full border opacity-0 group-hover:opacity-100 transition-opacity ${isNext ? 'border-white/50 text-white' : (theme === 'dark' ? 'border-slate-600 text-slate-400' : 'border-slate-300 text-slate-500')}`}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

          </div>
        )}

        {/* Footer */}
        {prayerData && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className={`mt-4 pb-4 text-center text-sm flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4 ${theme === 'dark' ? 'text-slate-500' : 'text-slate-400'}`}>
            <span>{t.source}</span>
            <span className="hidden sm:inline">•</span>
            <span>{prayerData.meta.timezone}</span>
            <span className="hidden sm:inline">•</span>
            <span>Yusuf TEKMIL tarafından Yapılmıştır ve Tüm Hakları Saklıdır.</span>
          </motion.div>
        )}

      </div>

      {/* Full Screen Prayer Modal */}
      {selectedPrayer && (
        <PrayerModal 
          prayerKey={selectedPrayer} 
          details={t.prayerDetails[selectedPrayer as keyof typeof t.prayerDetails]} 
          t={t} 
          onClose={() => setSelectedPrayer(null)} 
          theme={theme}
        />
      )}

      {/* Hidden Adhan Audio Player */}
      {playingAdhan && (
        <div className="hidden">
          <iframe
            src={`https://www.youtube.com/embed/${playingAdhan}?autoplay=1&controls=0&showinfo=0&rel=0`}
            allow="autoplay"
            title="Adhan Audio"
          ></iframe>
        </div>
      )}

      {/* Monthly Calendar Modal */}
      <AnimatePresence>
        {showMonthlyCalendar && location && (
          <MonthlyCalendarModal
            location={location}
            theme={theme}
            onClose={() => setShowMonthlyCalendar(false)}
            lang={lang}
            t={t}
            temkin={temkin}
          />
        )}
      </AnimatePresence>

      {/* Temkin Settings Modal */}
      <AnimatePresence>
        {showTemkinModal && (
          <TemkinModal
            theme={theme}
            onClose={() => setShowTemkinModal(false)}
            temkin={temkin}
            onSave={(newTemkin) => {
              setTemkin(newTemkin);
              localStorage.setItem('temkin', JSON.stringify(newTemkin));
              if (location) {
                fetchPrayerTimes(location.lat, location.lon, location.name, newTemkin);
              }
            }}
            t={t}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
