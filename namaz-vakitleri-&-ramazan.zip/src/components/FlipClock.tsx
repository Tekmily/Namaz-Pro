import React from 'react';

const TimeUnit = ({ val }: { val: number }) => {
  const valStr = String(val).padStart(2, '0');
  return (
    <div className="flex flex-col items-center justify-center">
      <span className="text-6xl sm:text-8xl font-black tracking-tighter drop-shadow-xl" style={{ fontVariantNumeric: 'tabular-nums' }}>
        {valStr}
      </span>
    </div>
  );
};

export const FlipClock = ({ hours, minutes, seconds }: { hours: number, minutes: number, seconds: number }) => {
  return (
    <div className="flex items-center justify-center gap-2 sm:gap-4 my-6 sm:my-8">
      <TimeUnit val={hours} />
      <span className="text-5xl sm:text-7xl font-black opacity-50 pb-2 sm:pb-4 animate-pulse drop-shadow-lg">:</span>
      <TimeUnit val={minutes} />
      <span className="text-5xl sm:text-7xl font-black opacity-50 pb-2 sm:pb-4 animate-pulse drop-shadow-lg">:</span>
      <TimeUnit val={seconds} />
    </div>
  );
};
