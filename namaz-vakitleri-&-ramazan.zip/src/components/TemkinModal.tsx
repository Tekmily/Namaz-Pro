import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Settings, Save } from 'lucide-react';

export interface TemkinOffsets {
  Imsak: number;
  Sunrise: number;
  Dhuhr: number;
  Asr: number;
  Maghrib: number;
  Isha: number;
}

interface TemkinModalProps {
  theme: 'dark' | 'light';
  onClose: () => void;
  temkin: TemkinOffsets;
  onSave: (newTemkin: TemkinOffsets) => void;
  t: any;
}

export function TemkinModal({ theme, onClose, temkin, onSave, t }: TemkinModalProps) {
  const [localTemkin, setLocalTemkin] = useState<TemkinOffsets>(temkin);

  const handleChange = (key: keyof TemkinOffsets, value: string) => {
    const num = parseInt(value, 10);
    setLocalTemkin(prev => ({
      ...prev,
      [key]: isNaN(num) ? 0 : num
    }));
  };

  const handleSave = () => {
    onSave(localTemkin);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }} 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        onClick={onClose} 
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.95, y: 20 }} 
        className={`relative w-full max-w-md flex flex-col rounded-3xl overflow-hidden shadow-2xl border ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b ${theme === 'dark' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50'}`}>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner ${theme === 'dark' ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-600'}`}>
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-xl font-bold tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                Temkin Ayarları
              </h2>
              <p className={`text-xs ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                Dakika olarak farkları ayarlayın (+/-)
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className={`p-2 rounded-full transition-colors ${theme === 'dark' ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'}`}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {Object.keys(localTemkin).map((key) => (
            <div key={key} className={`flex items-center justify-between p-3 rounded-xl border ${theme === 'dark' ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <span className={`font-medium ${theme === 'dark' ? 'text-slate-200' : 'text-slate-700'}`}>
                {t.prayers[key as keyof typeof t.prayers] || key}
              </span>
              <div className="flex items-center gap-2">
                <input 
                  type="number" 
                  value={localTemkin[key as keyof TemkinOffsets]} 
                  onChange={(e) => handleChange(key as keyof TemkinOffsets, e.target.value)}
                  className={`w-20 text-center px-3 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-amber-500 ${theme === 'dark' ? 'bg-slate-900 border-slate-600 text-white' : 'bg-white border-slate-300 text-slate-900'}`}
                />
                <span className={`text-sm ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>dk</span>
              </div>
            </div>
          ))}
          
          <div className={`text-xs mt-4 p-3 rounded-lg ${theme === 'dark' ? 'bg-sky-900/30 text-sky-300' : 'bg-sky-50 text-sky-700'}`}>
            <strong>Bilgi:</strong> Diyanet'in bölgesel temkin (güvenlik) süreleri her şehir için farklılık gösterir. Eğer vakitlerde fark görüyorsanız, buradaki değerleri değiştirerek tam uyum sağlayabilirsiniz.
          </div>
        </div>

        {/* Footer */}
        <div className={`p-6 border-t flex justify-end ${theme === 'dark' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50'}`}>
          <button 
            onClick={handleSave}
            className={`px-6 py-3 rounded-xl font-semibold flex items-center gap-2 transition-all active:scale-95 shadow-lg ${theme === 'dark' ? 'bg-amber-600 hover:bg-amber-500 text-white' : 'bg-amber-500 hover:bg-amber-600 text-white'}`}
          >
            <Save className="w-5 h-5" />
            Kaydet ve Yenile
          </button>
        </div>
      </motion.div>
    </div>
  );
}
