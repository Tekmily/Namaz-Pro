import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface PrayerModalProps {
  prayerKey: string;
  details: any;
  t: any;
  onClose: () => void;
  theme: string;
}

export const PrayerModal = ({ prayerKey, details, t, onClose, theme }: PrayerModalProps) => {
  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className={`relative w-full max-w-4xl aspect-video rounded-3xl overflow-hidden shadow-2xl border border-white/20 flex flex-col justify-end p-8 sm:p-12`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Background Video */}
          <video 
            autoPlay 
            loop 
            muted 
            playsInline 
            className="video-bg"
            src={details.video}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

          {/* Close Button */}
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white backdrop-blur-md transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Content */}
          <div className="relative z-10 text-white space-y-4">
            <div className="flex items-center gap-4 mb-2">
              <span className="text-5xl drop-shadow-lg">{details.emoji}</span>
              <h2 className="text-4xl sm:text-5xl font-bold drop-shadow-lg">{t.prayers[prayerKey as keyof typeof t.prayers]}</h2>
            </div>
            
            <div className="space-y-4 border-l-4 border-sky-500 pl-6 py-2">
              <p className="text-xl sm:text-2xl font-medium leading-relaxed drop-shadow-md">
                " {details.verse} "
              </p>
              <p className="text-lg sm:text-xl text-sky-200 italic drop-shadow-md">
                ✨ {details.hadith}
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
