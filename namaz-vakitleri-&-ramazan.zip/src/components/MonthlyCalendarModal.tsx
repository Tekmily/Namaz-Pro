import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { TemkinOffsets } from './TemkinModal';

interface MonthlyCalendarModalProps {
  location: { lat: number; lon: number; name: string };
  theme: 'dark' | 'light';
  onClose: () => void;
  lang: 'tr';
  t: any;
  temkin: TemkinOffsets;
}

export function MonthlyCalendarModal({ location, theme, onClose, lang, t, temkin }: MonthlyCalendarModalProps) {
  const [calendarData, setCalendarData] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const addMinutesToTime = (timeStr: string, minutes: number) => {
    if (!minutes) return timeStr;
    const [h, m] = timeStr.split(':').map(Number);
    const date = new Date();
    date.setHours(h, m + minutes, 0, 0);
    return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  };

  useEffect(() => {
    const fetchMonthlyData = async () => {
      setLoading(true);
      setError('');
      try {
        const date = new Date();
        const year = date.getFullYear();
        const month = date.getMonth() + 1;
        
        const parts = location.name.split(',');
        const city = parts[0].trim();
        const country = parts.length > 1 ? parts[parts.length - 1].trim() : 'Turkey';

        // 1. Fetch base data from Aladhan
        const aladhanRes = await fetch(`https://api.aladhan.com/v1/calendarByCity/${year}/${month}?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=13`);
        const aladhanData = await aladhanRes.json();
        
        if (aladhanData.code === 200) {
          let finalData = aladhanData.data;

          // 2. Try to fetch exact Diyanet data
          try {
            const searchRes = await fetch(`https://ezanvakti.imsakiyem.com/api/locations/search/districts?q=${encodeURIComponent(city)}`);
            const searchData = await searchRes.json();
            
            if (searchData.success && searchData.data && searchData.data.length > 0) {
              const districtId = searchData.data[0]._id;
              const diyanetRes = await fetch(`https://ezanvakti.imsakiyem.com/api/prayer-times/${districtId}/monthly`);
              const diyanetData = await diyanetRes.json();
              
              if (diyanetData.success && diyanetData.data && diyanetData.data.length > 0) {
                // Map Diyanet data to Aladhan data by matching dates
                finalData = finalData.map((day: any) => {
                  // Aladhan date format: DD-MM-YYYY
                  const aladhanDateStr = day.date.gregorian.date;
                  
                  // Find matching Diyanet day
                  const matchingDiyanetDay = diyanetData.data.find((dDay: any) => {
                    const dDate = new Date(dDay.date);
                    const dDateStr = `${String(dDate.getDate()).padStart(2, '0')}-${String(dDate.getMonth() + 1).padStart(2, '0')}-${dDate.getFullYear()}`;
                    return dDateStr === aladhanDateStr;
                  });

                  if (matchingDiyanetDay) {
                    const dTimes = matchingDiyanetDay.times;
                    return {
                      ...day,
                      timings: {
                        ...day.timings,
                        Imsak: dTimes.imsak,
                        Fajr: dTimes.imsak,
                        Sunrise: dTimes.gunes,
                        Dhuhr: dTimes.ogle,
                        Asr: dTimes.ikindi,
                        Maghrib: dTimes.aksam,
                        Isha: dTimes.yatsi
                      }
                    };
                  }
                  return day;
                });
              }
            }
          } catch (e) {
            console.error("Diyanet API error, falling back to Aladhan:", e);
          }

          // 3. Apply Temkin offsets
          finalData = finalData.map((day: any) => ({
            ...day,
            timings: {
              ...day.timings,
              Imsak: addMinutesToTime(day.timings.Imsak.split(' ')[0], temkin.Imsak),
              Fajr: addMinutesToTime(day.timings.Fajr.split(' ')[0], temkin.Imsak),
              Sunrise: addMinutesToTime(day.timings.Sunrise.split(' ')[0], temkin.Sunrise),
              Dhuhr: addMinutesToTime(day.timings.Dhuhr.split(' ')[0], temkin.Dhuhr),
              Asr: addMinutesToTime(day.timings.Asr.split(' ')[0], temkin.Asr),
              Maghrib: addMinutesToTime(day.timings.Maghrib.split(' ')[0], temkin.Maghrib),
              Isha: addMinutesToTime(day.timings.Isha.split(' ')[0], temkin.Isha)
            }
          }));

          setCalendarData(finalData);
        } else {
          setError(t.error);
        }
      } catch (err) {
        setError(t.error);
      } finally {
        setLoading(false);
      }
    };

    fetchMonthlyData();
  }, [location, t.error, temkin]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }} 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        onClick={onClose} 
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.95, y: 20 }} 
        className={`relative w-full max-w-5xl max-h-[90vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border ${theme === 'dark' ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between p-6 border-b ${theme === 'dark' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50'}`}>
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner ${theme === 'dark' ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-100 text-indigo-600'}`}>
              <CalendarIcon className="w-6 h-6" />
            </div>
            <div>
              <h2 className={`text-2xl font-bold tracking-tight ${theme === 'dark' ? 'text-white' : 'text-slate-900'}`}>
                Aylık Takvim
              </h2>
              <p className={`text-sm ${theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}`}>
                {location.name}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className={`p-2 rounded-full transition-colors ${theme === 'dark' ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'}`}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 custom-scrollbar">
          {loading ? (
            <div className="flex flex-col items-center justify-center h-64 gap-4">
              <Loader2 className={`w-10 h-10 animate-spin ${theme === 'dark' ? 'text-sky-400' : 'text-sky-600'}`} />
              <p className={theme === 'dark' ? 'text-slate-400' : 'text-slate-500'}>Takvim yükleniyor...</p>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center h-64 text-red-500">
              {error}
            </div>
          ) : calendarData ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[800px]">
                <thead>
                  <tr className={`border-b-2 ${theme === 'dark' ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'}`}>
                    <th className="py-4 px-4 font-semibold">Tarih</th>
                    <th className="py-4 px-4 font-semibold">İmsak</th>
                    <th className="py-4 px-4 font-semibold">Güneş</th>
                    <th className="py-4 px-4 font-semibold">Öğle</th>
                    <th className="py-4 px-4 font-semibold">İkindi</th>
                    <th className="py-4 px-4 font-semibold">Akşam</th>
                    <th className="py-4 px-4 font-semibold">Yatsı</th>
                  </tr>
                </thead>
                <tbody>
                  {calendarData.map((day, idx) => {
                    const isToday = day.date.gregorian.date === new Date().toLocaleDateString('en-GB').replace(/\//g, '-');
                    return (
                      <tr 
                        key={idx} 
                        className={`border-b transition-colors ${
                          isToday 
                            ? (theme === 'dark' ? 'bg-sky-900/30 border-sky-800/50' : 'bg-sky-50 border-sky-200') 
                            : (theme === 'dark' ? 'border-slate-800/50 hover:bg-slate-800/30' : 'border-slate-100 hover:bg-slate-50')
                        }`}
                      >
                        <td className="py-3 px-4">
                          <div className={`font-medium ${isToday ? (theme === 'dark' ? 'text-sky-400' : 'text-sky-700') : (theme === 'dark' ? 'text-slate-300' : 'text-slate-700')}`}>
                            {day.date.readable}
                          </div>
                          <div className={`text-xs ${theme === 'dark' ? 'text-slate-500' : 'text-slate-400'}`}>
                            {day.date.hijri.day} {day.date.hijri.month.tr || day.date.hijri.month.en} {day.date.hijri.year}
                          </div>
                        </td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Imsak.split(' ')[0]}</td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Sunrise.split(' ')[0]}</td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Dhuhr.split(' ')[0]}</td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Asr.split(' ')[0]}</td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Maghrib.split(' ')[0]}</td>
                        <td className={`py-3 px-4 font-mono ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>{day.timings.Isha.split(' ')[0]}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : null}
        </div>
      </motion.div>
    </div>
  );
}
