export const translations = {
  tr: {
    title: "Namaz Vakitleri 🕌",
    subtitle: "Dünyanın neresinde olursan ol 🌍",
    searchPlaceholder: "Örn. İstanbul, Türkiye",
    searchBtn: "Ara",
    useLocation: "Konumumu Kullan",
    nextPrayer: "Sıradaki Vakit ✨",
    timeLeft: "kaldı",
    currently: "Şu an",
    timeFor: "vakti.",
    prayers: { Imsak: "İmsak", Fajr: "Sabah", Sunrise: "Güneş", Dhuhr: "Öğle", Asr: "İkindi", Maghrib: "Akşam", Isha: "Yatsı" },
    loading: "Yükleniyor... ⏳",
    error: "Bir hata oluştu ❌",
    locationError: "Konum bulunamadı veya izin verilmedi 📍",
    source: "Kaynak: AlAdhan API",
    moonPhases: { new: "Yeni Ay", waxingCrescent: "Hilal (Büyüyen)", firstQuarter: "İlk Dördün", waxingGibbous: "Şişkin Ay (Büyüyen)", full: "Dolunay", waningGibbous: "Şişkin Ay (Küçülen)", lastQuarter: "Son Dördün", waningCrescent: "Hilal (Küçülen)" },
    ramadan: {
      title: "Ramazan Özel 🌙",
      iftar: "İftara Kalan Süre",
      sahur: "Sahura Kalan Süre",
      music: "Ramazan İlahileri & Müzikleri 🎶"
    },
    prayerDetails: {
      Imsak: { 
        verse: "Fecr vakti beyaz iplik siyah iplikten ayırt edilinceye kadar yiyin için. (Bakara, 187)", 
        hadith: "Sahur yapınız, zira sahurda bereket vardır. (Buhârî, Savm 20)",
        emoji: "🌙✨",
        video: "https://cdn.pixabay.com/video/2021/08/04/83864-584752661_large.mp4",
        images: ["https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1505322022379-7c3353ee6291?auto=format&fit=crop&q=80&w=800"]
      },
      Fajr: { 
        verse: "Sabah namazını kılın, çünkü sabah namazında melekler şahitlik eder. (İsrâ, 78)", 
        hadith: "Kim sabah namazını kılarsa, o Allah'ın güvencesi altındadır. (Müslim, Mesâcid 261)",
        emoji: "🌅🕊️",
        video: "https://cdn.pixabay.com/video/2020/05/25/40134-424855590_large.mp4",
        images: ["https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&q=80&w=800"]
      },
      Sunrise: { 
        verse: "Güneş doğarken ve batarken Rabbini hamd ile tespih et. (Tâhâ, 130)", 
        hadith: "Kim sabah namazını cemaatle kılar, sonra güneş doğuncaya kadar oturup Allah'ı zikrederse... (Tirmizî, Cuma 59)",
        emoji: "☀️🌄",
        video: "https://cdn.pixabay.com/video/2019/11/14/29037-372957913_large.mp4",
        images: ["https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=800"]
      },
      Dhuhr: { 
        verse: "Gündüzün güneş dönüp gölgesi uzadığında namazı kıl. (İsrâ, 78)", 
        hadith: "Öğle namazı, günün ortasında kılınan, gök kapılarının açıldığı bir namazdır. (Tirmizî, Vitir 15)",
        emoji: "☀️🕌",
        video: "https://cdn.pixabay.com/video/2020/04/18/36551-411475704_large.mp4",
        images: ["https://images.unsplash.com/photo-1585036156171-384164a8c675?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1564121211835-e88c852648ab?auto=format&fit=crop&q=80&w=800"]
      },
      Asr: { 
        verse: "Namazlara ve bilhassa orta namaza (ikindiye) dikkat edin. (Bakara, 238)", 
        hadith: "İkindi namazını terk edenin ameli boşa gider. (Buhârî, Mevâkît 15)",
        emoji: "🌤️🕋",
        video: "https://cdn.pixabay.com/video/2021/04/20/71694-540344465_large.mp4",
        images: ["https://images.unsplash.com/photo-1519817650390-64a93db51149?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1542816417-0983c9c9ad53?auto=format&fit=crop&q=80&w=800"]
      },
      Maghrib: { 
        verse: "Akşam vaktinde Rabbini tespih et. (Rûm, 17)", 
        hadith: "Akşam namazı acele kılınmalıdır. (Ebû Dâvûd, Salât 6)",
        emoji: "🌇🤲",
        video: "https://cdn.pixabay.com/video/2020/05/25/40135-424855601_large.mp4",
        images: ["https://images.unsplash.com/photo-1495616811223-4d98c6e9c869?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&q=80&w=800"]
      },
      Isha: { 
        verse: "Gecenin bir kısmında O'na secde et ve geceleyin O'nu uzun uzun tespih et. (İnsan, 26)", 
        hadith: "Yatsı namazını cemaatle kılan, gecenin yarısını ihya etmiş gibidir. (Müslim, Mesâcid 260)",
        emoji: "🌌📿",
        video: "https://cdn.pixabay.com/video/2021/08/04/83864-584752661_large.mp4",
        images: ["https://images.unsplash.com/photo-1513628253939-010e64ac66cd?auto=format&fit=crop&q=80&w=800", "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?auto=format&fit=crop&q=80&w=800"]
      }
    },
    notifTitle: "Namaz Vakti!",
    notifBody: "vakti girdi. Namazını kılmayı unutma."
  }
};

export const getMoonPhase = (date: Date) => {
  let year = date.getFullYear();
  let month = date.getMonth() + 1;
  let day = date.getDate();
  if (month < 3) { year--; month += 12; }
  ++month;
  let c = 365.25 * year;
  let e = 30.6 * month;
  let jd = c + e + day - 694039.09;
  jd /= 29.5305882;
  let b = Math.floor(jd);
  jd -= b;
  let b2 = Math.round(jd * 8);
  if (b2 >= 8) b2 = 0;
  const phases = ['new', 'waxingCrescent', 'firstQuarter', 'waxingGibbous', 'full', 'waningGibbous', 'lastQuarter', 'waningCrescent'] as const;
  const emojis = ['🌑', '🌒', '🌓', '🌔', '🌕', '🌖', '🌗', '🌘'];
  return { key: phases[b2], emoji: emojis[b2] };
};
